package com.example.calendar;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.TextView;




public class DayView extends LinearLayout {

    public static final int MAX_NUMBER_OF_SCHEDULE_TO_DISPLAY = 5;
    public static final int MAX_NUMBER_OF_SCHEDULE = 10;

    private int day;
    private int numberOfHolidays;
    private Schedule[] schedulesInDay = new Schedule[MAX_NUMBER_OF_SCHEDULE];
    private TextView dayText;
    private TextView[] textViews = new TextView[MAX_NUMBER_OF_SCHEDULE_TO_DISPLAY];

    public DayView(Context context, int day) {
        super(context);
        this.day = day;
        init();
    }


    private void init() {
        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(getContext().LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.day_view, this);
        setOrientation(LinearLayout.VERTICAL);

        numberOfHolidays = 0;
        dayText = findViewById(R.id.day_text);
        textViews[0]=((TextView) findViewById(R.id.schedule_text1));
        textViews[1]=((TextView) findViewById(R.id.schedule_text2));
        textViews[2]=((TextView) findViewById(R.id.schedule_text3));
        textViews[3]=((TextView) findViewById(R.id.schedule_text4));
        dayText.setText(String.valueOf(day));
    }

    public TextView getDayText() {
        return dayText;
    }
    public TextView[] getTextViews() {
        return textViews;
    }
}
