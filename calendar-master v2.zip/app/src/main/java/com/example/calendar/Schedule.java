package com.example.calendar;

import android.graphics.Color;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;

public class Schedule{

    private final Color defaultColor = Color.valueOf(1f, 0.5f, 0.5f);
    static int num = 1;
    private int id;
    private String title = null;
    private LocalDate startDate = null;
    private LocalDate endDate = null;
    private LocalTime startTime = null;
    private LocalTime endTime = null;
    private String memo = null;
    private Color color = defaultColor;
    private boolean isHoliday = false;

    public Schedule(String title, LocalDate startDate, LocalDate endDate,
                    LocalTime startTime, LocalTime endTime) {
        this.id = num;
        num++;
        this.title = title;
        this.startDate = startDate;
        this.endDate = endDate;
        this.startTime = startTime;
        this.endTime = endTime;
        this.isHoliday = false;
    }

    public Schedule(String title, LocalDate startDate, LocalDate endDate  ) {
        this.id = num;
        num++;
        this.title = title;
        this.startDate = startDate;
        this.endDate = endDate;
        this.isHoliday = false;
    }
    public Schedule(String title, LocalDate startDate, LocalDate endDate, boolean isHoliday) {
        this.id = num;
        num++;
        this.title = title;
        this.startDate = startDate;
        this.endDate = endDate;
        this.isHoliday=isHoliday;
    }


    public Color getColor() {  return color;  }

    public void setColor(Color color) {
        this.color = color;
    }


    public boolean isHoliday() {
        return isHoliday;
    }

    public int getID() { return id; }

    public String getTitle() {  return title; }

    public LocalDate getStartDate() {
        return startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public int getLengthOfSchedule(){
        return (int) ChronoUnit.DAYS.between(startDate, endDate) + 1;
    }




}
