package com.example.calendar;
import org.w3c.dom.Document;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;

import android.os.AsyncTask;
import android.text.Layout;
import android.util.AttributeSet;
import android.view.LayoutInflater;

import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.annotation.Nullable;

import androidx.viewpager.widget.ViewPager;


import com.github.florent37.expansionpanel.ExpansionHeader;
import com.github.florent37.expansionpanel.ExpansionLayout;
import com.github.florent37.expansionpanel.viewgroup.ExpansionLayoutCollection;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;


import java.net.URL;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class CalendarView extends LinearLayout {


    public static final int defaultValueOfPage = 50000;
    public static final int marginPixelBetweenPage = 50;


    private Map<LocalDate, Schedule> holidays;
    private Map<LocalDate, Schedule> schedules;
    private Map<Integer, Schedule> holidays2;
    private Map<Integer, Schedule> schedules2;
    private LocalDate defaultDate;
    private Context context;
    private CalendarViewPagerAdapter calendarViewPagerAdapter;

    private ViewPager viewPager;
    private TextView monthText;

    private LocalDate startDate = LocalDate.now();
    private LocalDate endDate = LocalDate.now();

    private LocalTime startTime = LocalTime.now();
    private LocalTime endTime = LocalTime.now();

    public CalendarView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);

        init(context);

    }





    private void init(Context context) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        inflater.inflate(R.layout.calendar_view, this);
        setOrientation(LinearLayout.VERTICAL);

        this.context = context;
        //defaultDate = 물리(현실)적인 현재 날짜의 1일 ex) 2020년 2월 1일
        defaultDate = LocalDate.now();
        defaultDate = defaultDate.minusDays(defaultDate.getDayOfMonth() - 1);
        schedules = new HashMap<>();
        holidays = new HashMap<>();
        schedules2 = new HashMap<>();
        holidays2 = new HashMap<>();


    }



    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();

        ImageButton buttonToAddSchedule = findViewById(R.id.button_to_add_schedule);
        viewPager = findViewById(R.id.calendar_pager);
        monthText = findViewById(R.id.month_text);



        new GetHolidaysTask(getContext()).execute();

        buttonToAddSchedule.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                final Dialog dialog = new Dialog(getContext());
                WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                lp.copyFrom(dialog.getWindow().getAttributes());
                lp.width = 1000;
                lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                dialog.setTitle("스케줄 추가");
                //dialog.setContentView(R.layout.add_schedule_dialog);
                ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                LinearLayout dialog_layout = (LinearLayout)View.inflate(context, R.layout.add_schedule_dialog, null);
                dialog.setContentView(dialog_layout);

                Window window = dialog.getWindow();
                window.setAttributes(lp);

                final TextView startDateText = dialog.findViewById(R.id.start_date);
                final TextView endDateText = dialog.findViewById(R.id.end_date);
                final TextView startTimeText = dialog.findViewById(R.id.start_time);
                final TextView endTimeText = dialog.findViewById(R.id.end_time);
                final Switch allDaySwitch = (Switch)dialog.findViewById(R.id.allDaySwitch);
                final EditText inputOfTitle = dialog.findViewById(R.id.title_input);
                final Switch switch_alarm = dialog.findViewById(R.id.switch_alarm);
                final Switch switch_repeat = dialog.findViewById(R.id.switch_repeat);
                final Switch switch_memo = dialog.findViewById(R.id.switch_memo);
                final Switch switch_dday = dialog.findViewById(R.id.switch_dday);
                final Switch switch_location = dialog.findViewById(R.id.switch_location);
                final Switch switch_participant = dialog.findViewById(R.id.switch_participant);

                final Button saveButton = dialog.findViewById(R.id.save_button);
                final Button cancelButton = dialog.findViewById(R.id.cancel_button);


                //final EditText inputOfMemo = dialog.findViewById(R.id.memo_input);

                startDateText.setText("시작 날짜 선택");
                endDateText.setText("종료 날짜 선택");
                startTimeText.setText("시작 시간 선택");
                endTimeText.setText("종료 시간 선택");

                allDaySwitch.setOnCheckedChangeListener(new Switch.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        if(isChecked){
                            startTimeText.setEnabled(false);
                            startTimeText.setClickable(false);
                            startTimeText.setVisibility(GONE);
                            endTimeText.setEnabled(false);
                            endTimeText.setClickable(false);
                            endTimeText.setVisibility(GONE);

                        }
                        else{
                            startTimeText.setEnabled(true);
                            startTimeText.setClickable(true);
                            startTimeText.setVisibility(VISIBLE);

                            endTimeText.setEnabled(true);
                            endTimeText.setClickable(true);
                            endTimeText.setVisibility(VISIBLE);
                        }
                    }
                });

                startDateText.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        DatePickerDialog datePickerDialog = new DatePickerDialog(getContext(), new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int month, int day) {
                                startDate = LocalDate.of(year, month, day);
                            }
                        }, startDate.getYear(), startDate.getMonthValue(), startDate.getDayOfMonth());

                        datePickerDialog.setMessage("시작 날짜 선택");
                        datePickerDialog.show();
                    }
                });

                endDateText.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        DatePickerDialog datePickerDialog = new DatePickerDialog(getContext(), new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int month, int day) {
                                endDate = LocalDate.of(year, month, day);
                            }
                        }, endDate.getYear(), endDate.getMonthValue(), endDate.getDayOfMonth());

                        datePickerDialog.setMessage("종료 날짜 선택");
                        datePickerDialog.show();
                    }
                });
                startTimeText.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        TimePickerDialog timePickerDialog = new TimePickerDialog(getContext(), new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker view, int hour, int minute) {
                                startTime = LocalTime.of(hour, minute);
                            }
                        }, startTime.getHour(), startTime.getMinute(), false);

                        timePickerDialog.setMessage("시작 시간 선택");
                        timePickerDialog.show();
                    }
                });

                endTimeText.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        TimePickerDialog timePickerDialog = new TimePickerDialog(getContext(), new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker view, int hour, int minute) {
                                endTime = LocalTime.of(hour, minute);
                            }
                        }, endTime.getHour(), endTime.getMinute(), false);

                        timePickerDialog.setMessage("종료 시간 선택");
                        timePickerDialog.show();
                    }
                });

                switch_alarm.setOnCheckedChangeListener(new Switch.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        ExpansionHeader expansionheader_alarm = dialog.findViewById(R.id.expansionheader_alarm);
                        ExpansionLayout expansionLayout_alarm = dialog.findViewById(R.id.expansionLayout_alarm);

                        if(isChecked){
                            expansionheader_alarm.setVisibility(VISIBLE);
                            expansionLayout_alarm.setVisibility(VISIBLE);
                        }
                        else{
                            expansionheader_alarm.setVisibility(GONE);
                            expansionLayout_alarm.setVisibility(GONE);
                        }
                    }
                });
                switch_repeat.setOnCheckedChangeListener(new Switch.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        ExpansionHeader expansionheader_repeat = dialog.findViewById(R.id.expansionheader_repeat);
                        ExpansionLayout expansionLayout_repeat = dialog.findViewById(R.id.expansionLayout_repeat);

                        if(isChecked){
                            expansionheader_repeat.setVisibility(VISIBLE);
                            expansionLayout_repeat.setVisibility(VISIBLE);
                        }
                        else{
                            expansionheader_repeat.setVisibility(GONE);
                            expansionLayout_repeat.setVisibility(GONE);
                        }
                    }
                });

                switch_memo.setOnCheckedChangeListener(new Switch.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        ExpansionHeader expansionheader_memo = dialog.findViewById(R.id.expansionheader_memo);
                        ExpansionLayout expansionLayout_memo = dialog.findViewById(R.id.expansionLayout_memo);

                        if(isChecked){
                            expansionheader_memo.setVisibility(VISIBLE);
                            expansionLayout_memo.setVisibility(VISIBLE);
                        }
                        else{
                            expansionheader_memo.setVisibility(GONE);
                            expansionLayout_memo.setVisibility(GONE);
                        }
                    }
                });

                switch_dday.setOnCheckedChangeListener(new Switch.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        ExpansionHeader expansionheader_dday = dialog.findViewById(R.id.expansionheader_dday);
                        ExpansionLayout expansionLayout_dday = dialog.findViewById(R.id.expansionLayout_dday);

                        if(isChecked){
                            expansionheader_dday.setVisibility(VISIBLE);
                            expansionLayout_dday.setVisibility(VISIBLE);
                        }
                        else{
                            expansionheader_dday.setVisibility(GONE);
                            expansionLayout_dday.setVisibility(GONE);
                        }
                    }
                });

                switch_location.setOnCheckedChangeListener(new Switch.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        ExpansionHeader expansionheader_location = dialog.findViewById(R.id.expansionheader_location);
                        ExpansionLayout expansionLayout_location = dialog.findViewById(R.id.expansionLayout_location);

                        if(isChecked){
                            expansionheader_location.setVisibility(VISIBLE);
                            expansionLayout_location.setVisibility(VISIBLE);
                        }
                        else{
                            expansionheader_location.setVisibility(GONE);
                            expansionLayout_location.setVisibility(GONE);
                        }
                    }
                });

                switch_participant.setOnCheckedChangeListener(new Switch.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        ExpansionHeader expansionheader_participant = dialog.findViewById(R.id.expansionheader_participant);
                        ExpansionLayout expansionLayout_participant = dialog.findViewById(R.id.expansionLayout_participant);

                        if(isChecked){
                            expansionheader_participant.setVisibility(VISIBLE);
                            expansionLayout_participant.setVisibility(VISIBLE);
                        }
                        else{
                            expansionheader_participant.setVisibility(GONE);
                            expansionLayout_participant.setVisibility(GONE);
                        }
                    }
                });


                saveButton.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String title = inputOfTitle.getText().toString();
                        //String memo = inputOfMemo.getText().toString();
                        Schedule schedule;
                        if(allDaySwitch.isChecked()) {
                            schedule = new Schedule(title, startDate, endDate);
                        }
                        else{
                            schedule = new Schedule(title, startDate, endDate, startTime, endTime);
                        }
                        if (title.equals("")) {
                            return;
                        }
                        //schedule.setMemo(memo);
                        addSchedule(schedule);
                        dialog.dismiss();
                    }
                });

                cancelButton.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                dialog.show();
            }
        });



    }
    class GetHolidaysTask extends AsyncTask<String, Void, ArrayList<Document>>{
        private Context context;
        private String solYear = null;
        private String solMonth = null;
        private final String serviceKey ="0959vP0phcvSpIzw11eydZh1GrRP72NwJTfoELAtETspltEMpWFN3ikd1piWIuX7wv3BoBcSF192o4bOBYlyMQ%3D%3D";



        public GetHolidaysTask(Context context) {
            this.context = context;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }
        @Override
        protected ArrayList<Document> doInBackground(String... strings) {
            URL url;
            ArrayList<Document> arrayOfDoc = new ArrayList<>();
            for(int y = 2015 ; y <= 2020 ; y++){
                for(int m = 1 ; m<=12 ; m++){
                    solYear = String.valueOf(y);
                    solMonth = m<10 ? "0"+m : ""+m;
                    try{
                        Document doc = null;
                        url = new URL("http://apis.data.go.kr/B090041/openapi/service/SpcdeInfoService/getHoliDeInfo?solYear="
                                + solYear +"&solMonth="+ solMonth +"&ServiceKey=" + serviceKey);
                        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
                        DocumentBuilder db = dbf.newDocumentBuilder();
                        doc = db.parse(new InputSource(url.openStream()));
                        doc.getDocumentElement().normalize();
                        arrayOfDoc.add(doc);
                    }
                    catch(Exception e){
                        e.printStackTrace();
                    }
                }
            }

            return arrayOfDoc;
        }

        @Override
        protected void onPostExecute(ArrayList<Document> arrayOfDoc) {
            super.onPostExecute(arrayOfDoc);
            for(int j = 0; j<arrayOfDoc.size(); j++) {
                Document doc = arrayOfDoc.get(j);
                NodeList itemNodeList = doc.getElementsByTagName("item");

                for (int i = 0; i < itemNodeList.getLength(); i++) {
                    Node node = itemNodeList.item(i);
                    Element element = (Element) node;
                    NodeList dateNameNodeList = element.getElementsByTagName("dateName");
                    NodeList locDateNodeList = element.getElementsByTagName("locdate");
                    String dateName = dateNameNodeList.item(0).getChildNodes().item(0).getNodeValue();
                    String locDate = locDateNodeList.item(0).getChildNodes().item(0).getNodeValue();

                    int year = Integer.parseInt(locDate.substring(0, 4));
                    int month = Integer.parseInt(locDate.substring(4, 6));
                    int day = Integer.parseInt(locDate.substring(6, 8));
                    LocalDate localDate = LocalDate.of(year,month, day);

                    Schedule holiday = new Schedule(dateName, localDate, localDate, true);
                    holidays.put(holiday.getStartDate(), holiday);
                    holidays2.put(holiday.getID(), holiday);
                }



            }
            monthText.setText(defaultDate.getYear() + "년 " + defaultDate.getMonthValue() + "월");

            calendarViewPagerAdapter = new CalendarViewPagerAdapter(getContext(), schedules, holidays, schedules2, holidays2, defaultDate);
            viewPager.setAdapter(calendarViewPagerAdapter);
            viewPager.setCurrentItem(defaultValueOfPage);
            viewPager.setPageMargin(marginPixelBetweenPage);
            viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

                }
                @Override
                public void onPageSelected(int position) {
                    LocalDate dateToShow = defaultDate.plusMonths(position - defaultValueOfPage);
                    monthText.setText(dateToShow.getYear() + "년 " + dateToShow.getMonthValue() + "월");
                }

                @Override
                public void onPageScrollStateChanged(int state) {

                }
            });
        }


    }

    public void addSchedule(Schedule schedule) {
        schedules.put(schedule.getStartDate(), schedule);
        schedules2.put(schedule.getID(), schedule);
        calendarViewPagerAdapter.notifyDataSetChanged();
        return;
    }







}

