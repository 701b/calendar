package com.example.calendar;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CalendarView calendarView = findViewById(R.id.calendar_view);




            Schedule schedule0 =
                    new Schedule("경준생일", LocalDate.of(2019, 1, 2),
                            LocalDate.of(2019, 1, 2),
                            LocalTime.of(0, 0, 0),
                            LocalTime.of(23, 59, 59));

        Schedule schedule1 =
                new Schedule("2020년", LocalDate.of(2020, 1, 1),
                        LocalDate.of(2020, 12, 31),
                        false);

        Schedule schedule2 =
                new Schedule("2월", LocalDate.of(2020, 2, 1),
                        LocalDate.of(2020, 2, 29),
                        false);
        Schedule schedule3 =
                new Schedule("2월중말", LocalDate.of(2020, 2, 15),
                        LocalDate.of(2020, 2, 29),
                        false);
        Schedule schedule4 =
                new Schedule("2월 초중", LocalDate.of(2020, 2, 1),
                        LocalDate.of(2020, 2, 15),
                        false);
        Schedule schedule5 =
                new Schedule("3월", LocalDate.of(2020, 3, 1),
                        LocalDate.of(2020, 3, 31),
                        false);
    }
}
