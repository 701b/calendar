package com.example.calendar;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;

import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;


public class CalendarViewPagerAdapter extends PagerAdapter {

    public final int MAX_NUMBER_OF_ROW = 5;
    public final int MAX_NUMBER_OF_DAY_IN_A_ROW = 7;



    private final LocalDate defaultDate;


    private Context context;
    private Map<LocalDate, Schedule> sortedSchedules;
    private Map<LocalDate, Schedule> sortedHolidays;
    private Map<LocalDate, Schedule> schedules;
    private Map<LocalDate, Schedule> holidays;
    private Map<Integer, Schedule> schedules2;
    private Map<Integer, Schedule> holidays2;

    public CalendarViewPagerAdapter(Context context,
                                    Map<LocalDate, Schedule> schedules,
                                    Map<LocalDate, Schedule> holidays,
                                    Map<Integer, Schedule> schedules2,
                                    Map<Integer, Schedule> holidays2,
                                    LocalDate defaultDate) {
        this.context = context;
        this.schedules = schedules;
        this.holidays = holidays;
        this.schedules2 = schedules2;
        this.holidays2 = holidays2;
        this.defaultDate = defaultDate;

    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {



        List<Map.Entry<LocalDate, Schedule>> scheduleList = new LinkedList<>(schedules.entrySet());

        Collections.sort(scheduleList, new Comparator<Map.Entry<LocalDate, Schedule>>() {
            @Override
            public int compare(Map.Entry<LocalDate, Schedule> o1, Map.Entry<LocalDate, Schedule> o2) {
                if(o1.getKey().isAfter(o2.getKey())){
                    return 1;
                }
                else if(o1.getKey().isBefore(o2.getKey())){
                    return -1;
                }
                else{
                    return o1.getValue().getLengthOfSchedule()-o2.getValue().getLengthOfSchedule();
                }
            }
        });
        // 순서유지를 위해 LinkedHashMap을 사용
        sortedSchedules = new LinkedHashMap<>();
        for(Iterator<Map.Entry<LocalDate, Schedule>> iter = scheduleList.iterator(); iter.hasNext();){
            Map.Entry<LocalDate, Schedule> entry = iter.next();
            sortedSchedules.put(entry.getKey(), entry.getValue());
        }

        List<Map.Entry<LocalDate, Schedule>> holidayList = new LinkedList<>(holidays.entrySet());

        Collections.sort(holidayList, new Comparator<Map.Entry<LocalDate, Schedule>>() {
            @Override
            public int compare(Map.Entry<LocalDate, Schedule> o1, Map.Entry<LocalDate, Schedule> o2) {
                if(o1.getKey().isAfter(o2.getKey())){
                    return 1;
                }
                else if(o1.getKey().isBefore(o2.getKey())){
                    return -1;
                }
                else{
                    return o1.getValue().getLengthOfSchedule()-o2.getValue().getLengthOfSchedule();
                }
            }
        });
        // 순서유지를 위해 LinkedHashMap을 사용
        sortedHolidays = new LinkedHashMap<>();
        for(Iterator<Map.Entry<LocalDate, Schedule>> iter = holidayList.iterator(); iter.hasNext();){
            Map.Entry<LocalDate, Schedule> entry = iter.next();
            sortedHolidays.put(entry.getKey(), entry.getValue());
        }












        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        LinearLayout monthView = (LinearLayout) inflater.inflate(R.layout.month_view, container, false);
        ArrayList<DayView> dayViews = new ArrayList<>();


        //기본 Layout 생성
        LocalDate monthToShow = defaultDate.plusMonths(position-CalendarView.defaultValueOfPage);
        LocalDate rearMonth = monthToShow.plusMonths(1);
        final int numberOfDayInFrontMonth = monthToShow.plusDays(1).getDayOfWeek().getValue() - 1;
        final int numberOfDayInRearMonth = MAX_NUMBER_OF_DAY_IN_A_ROW * MAX_NUMBER_OF_ROW - monthToShow.lengthOfMonth() - numberOfDayInFrontMonth;
        LocalDate startDateInCalendar = monthToShow.plusDays(-numberOfDayInFrontMonth);
        LocalDate endDateInCalendar = rearMonth.plusDays(numberOfDayInRearMonth - 1);


        LocalDate dateIterator = startDateInCalendar;
        for (int i = 0; i < MAX_NUMBER_OF_ROW; i++) {
            LinearLayout weekView = new LinearLayout(context);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);

            layoutParams.weight = 1;
            layoutParams.setMargins((int) (10 * context.getResources().getDisplayMetrics().density), 0, (int) (10 * context.getResources().getDisplayMetrics().density), 0);
            weekView.setOrientation(LinearLayout.HORIZONTAL);
            weekView.setLayoutParams(layoutParams);
            monthView.addView(weekView);

            for (int j = 0; j < MAX_NUMBER_OF_DAY_IN_A_ROW; j++, dateIterator = dateIterator.plusDays(1)) {
                int day = dateIterator.getDayOfMonth();
                DayView dayView = new DayView(weekView.getContext(), day);
                LinearLayout.LayoutParams dayViewLayoutParams =
                        new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                                LinearLayout.LayoutParams.MATCH_PARENT);
                dayViewLayoutParams.weight = 1;
                dayView.setLayoutParams(dayViewLayoutParams);
                weekView.addView(dayView);
                dayViews.add(dayView);
            }
        }


        //토, 일요일 설정
        for(int i = 0 ; i<MAX_NUMBER_OF_ROW ; ++i) {
            dayViews.get(7 * i).getDayText().setTextColor(Color.RED);
            dayViews.get(7 * i + 6).getDayText().setTextColor(Color.BLUE);
        }
        //schedulesInMonth 초기화
        int[][] schedulesInMonth = new int[MAX_NUMBER_OF_DAY_IN_A_ROW*MAX_NUMBER_OF_ROW][DayView.MAX_NUMBER_OF_SCHEDULE];
        for(LocalDate holidayDate : sortedHolidays.keySet()){
            Schedule holiday = sortedHolidays.get(holidayDate);
            if(holiday.getEndDate().isBefore(startDateInCalendar)||holiday.getStartDate().isAfter(endDateInCalendar)){
                continue;
            }
            else{
                int index_start = dateToIndex(startDateInCalendar, holiday.getStartDate());
                int index_end = dateToIndex(startDateInCalendar, holiday.getEndDate());
                for(int i = index_start ; i<=index_end ; ++i) {
                    schedulesInMonth[i][0] = holiday.getID();
                    if(i==index_start){
                        schedulesInMonth[i][0] = -holiday.getID();

                    }
                }
            }
        }
        System.out.println(schedulesInMonth);

        for(LocalDate scheduleDate : sortedSchedules.keySet()){
            Schedule schedule = sortedSchedules.get(scheduleDate);


            if(schedule.getEndDate().isBefore(startDateInCalendar)||schedule.getStartDate().isAfter(endDateInCalendar)){
                continue;
            }
            else {
                int index_start = dateToIndex(startDateInCalendar, schedule.getStartDate());
                int index_end = dateToIndex(startDateInCalendar, schedule.getEndDate());
                for(int row = 0 ; row<DayView.MAX_NUMBER_OF_SCHEDULE ; ++row) {
                    if (isAllZero(schedulesInMonth, row, index_start, index_end)) {
                        for(int i = index_start ; i<=index_end ; ++i) {
                            schedulesInMonth[i][row] = schedule.getID();
                            if(i==index_start){
                                schedulesInMonth[i][row] = -schedule.getID();
                            }
                        }
                        break;
                    }
                    //다 찼다는 예외를 던진다.
                    //
                    //
                    //
                }

            }
        }



        // schedulesInMonth을 이용해서 스케줄 설정
        for(int row = 0 ; row<DayView.MAX_NUMBER_OF_SCHEDULE ; ++row){
            for(int col = 0 ; col<MAX_NUMBER_OF_DAY_IN_A_ROW*MAX_NUMBER_OF_ROW ;++col){
                boolean isFirst = false;
                int id = schedulesInMonth[col][row];
                if(id!=0){
                    if(id<0){
                        id=-id;
                        isFirst = true;
                    }
                    Schedule schedule = schedules2.get(id);
                    if(schedule==null){
                        schedule=holidays2.get(id);
                    }
                    DayView dayView = dayViews.get(col);
                    dayView.getTextViews()[row].setBackgroundColor(schedule.getColor().toArgb());
                    if(isFirst){
                        dayView.getTextViews()[row].setText(schedule.getTitle());
                    }
                }
            }
        }

        //날씨 설정
        //
        //
        //
        //

        container.addView(monthView);


        return monthView;
    }

    boolean isAllZero(int[][] arr, int row, int index_start, int index_end){
        for(int i = index_start ; i<=index_end ; ++i){
            if(arr[i][row]!=0){
                return false;
            }
        }
        return true;
    }
    //date에 해당하는dayView가 dayViews에서 몇번째 항목에 있는지 반환
    int dateToIndex(LocalDate startDateInCalendar, LocalDate date){
        int ret = (int) ChronoUnit.DAYS.between(startDateInCalendar, date);
        if(ret<0){
            return 0;
        }
        if(ret>=MAX_NUMBER_OF_ROW*MAX_NUMBER_OF_DAY_IN_A_ROW){
            return MAX_NUMBER_OF_ROW*MAX_NUMBER_OF_DAY_IN_A_ROW-1;
        }

        return ret;
    }

    @Override
    public int getItemPosition(@NonNull Object object) {
        return POSITION_NONE;
    }

    @Override
    public int getCount() {
        return 100000;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((View) object);
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return (view == (View) object);
    }
}
