package com.example.calendar;

import android.app.Activity;

public class SplashActivity extends Activity {

}
